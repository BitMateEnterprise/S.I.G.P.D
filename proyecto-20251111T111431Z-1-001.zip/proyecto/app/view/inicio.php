<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Draftosaurus - Inicio</title>  
  <link rel="icon" type="image/png" href="assets/Imagenes/Logo.png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />

    <style>
    body{
      background-image: url("assets/Imagenes/fondo.png");
      background-size: cover;
      background-repeat: no-repeat;
      background-attachment: fixed;
      min-height: 100vh;
      margin: 0;
      padding: 0;
    }

    html {
      margin: 0;
      padding: 0;
    }
    
    /* Ocultar el div inicialmente */
    #contenido-principal {
      opacity: 0;
      transform: translateY(20px);
      transition: opacity 0.8s ease-out, transform 0.8s ease-out;
    }
    
    /* Clase para mostrar el div con animación */
    #contenido-principal.mostrar {
      opacity: 1;
      transform: translateY(0);
    }
  </style>
  <link rel="stylesheet" href="./css/estilo.css" />
</head>
<body class="d-flex justify-content-center align-items-center vh-100">

<div id="contenido-principal" class="text-center border rounded p-4 shadow" style="width: 90%; max-width: 400px; background-color: rgba(200, 200, 200, 0.6);">
 
    <img src="assets/Imagenes/Logo.png" alt="Logo Draftosaurus" class="img-fluid mb-3" style="max-height: 150px;">

    <h1 class="mb-3">Drafto Craft Web</h1>

    <p class="mb-3 fs-5">
      Bienvenido a la app de seguimiento de Drafto Craft.<br>
      Iniciá sesión o regístrate para comenzar a registrar la partida.
    </p>
    
    <div class="d-flex flex-column gap-2">
      <a href="index.php?ruta=login" class="btn btn-primary">Iniciar sesión</a>
      <a href="index.php?ruta=registro" class="btn btn-success">Registrarse</a>
    </div>
  </div>
<script>
  // Mostrar el contenido después de 1 segundo
  window.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
      document.getElementById('contenido-principal').classList.add('mostrar');
    }, 1000); // 1000 milisegundos = 1 segundo
  });
</script>
</body>
</html>
