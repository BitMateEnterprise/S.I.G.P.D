<?php
class Estadisticas {
    private int $totalPuntos;
    private int $partidasJugadas;
    private int $partidasGanadas;
    private array $ranking;

    public function __construct(int $totalPuntos, int $partidasJugadas, int $partidasGanadas, array $ranking) {
        $this->totalPuntos = $totalPuntos;
        $this->partidasJugadas = $partidasJugadas;
        $this->partidasGanadas = $partidasGanadas;
        $this->ranking = $ranking;
    }

    public function getTotalPuntos(): int {
        return $this->totalPuntos;
    }

    public function getPartidasJugadas(): int {
        return $this->partidasJugadas;
    }

    public function getPartidasGanadas(): int {
        return $this->partidasGanadas;
    }

    public function getRanking(): array {
        return $this->ranking;
    }

}