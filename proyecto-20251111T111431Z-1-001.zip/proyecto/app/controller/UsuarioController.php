<?php
require_once __DIR__ . '/../model/UsuarioDAO.php';

class UsuarioController {

  public function obtenerUsuario($apodo) {
    $apodo = $_GET['apodo'];

    $usuario = (new UsuarioDAO())->consultarUsuario($apodo);

    header('Content-Type: application/json');
    echo json_encode($usuario);
    exit;
  }

  public function eliminarCuenta(){
    if($_SERVER["REQUEST_METHOD"] === "POST"){
      $apodo = $_SESSION["usuario"];
      (new UsuarioDAO())->eliminarUsuario($apodo);   
      header("Location: index.php?ruta=inicio");
      exit;   
    }
  }

  public function modificarDatos(){
    if($_SERVER["REQUEST_METHOD"] === "POST"){
      (new UsuarioDAO())->modificarUsuario($_POST["apodo"],$_POST["email"]);
      header("Location: index.php?ruta=perfil");
      exit;
    }
  }
}