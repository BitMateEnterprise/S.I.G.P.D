const usuarioIngresado = document.getElementById("usuario");
const claveIngresada = document.getElementById("clave");
const mensajeError = document.getElementById("mensaje");

usuarioIngresado.addEventListener("keypress", e => {
  const expresion = /^[a-zA-Z0-9]$/;
  if (!expresion.test(e.key)) {
    e.preventDefault();
  }
});

document.getElementById("enviarDatos").addEventListener("submit", e => {

  mensajeError.style.display = "none";
  mensajeError.textContent = "";
  const usuario = usuarioIngresado.value.trim();
  const clave = claveIngresada.value.trim();
  let errores = [];
  const expresion = /^[a-zA-Z0-9]+$/;

  // Validaciones
  if(!expresion.test(usuario) || usuario.length < 3){
    errores.push("El nombre de usuario es inválido");
  }

  if(clave.length < 4){
    errores.push("La clave debe contener 4 o más letras");
  }

  console.log(errores);
  //No enviar si existen errores
  if (errores.length > 0) {
    e.preventDefault();
    mensajeError.textContent = errores.join(" ");
    mensajeError.style.display = "block";
  }
});