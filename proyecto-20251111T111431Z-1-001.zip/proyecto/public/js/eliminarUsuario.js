const modal = new bootstrap.Modal('#modalEliminarCuenta');
const btnAbrir = document.getElementById('eliminarCuenta');
const btnSi = document.getElementById('btnEliminarSi');
const formulario = document.getElementById('eliminarUsuario');

btnAbrir.addEventListener('click', () => modal.show());
btnSi.addEventListener('click', () => formulario.submit());