<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Tablero - Drafto Craft</title>
  <link rel="icon" type="image/png" href="assets/Imagenes/Logo.png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link rel="stylesheet" href="./css/estilo.css" />  

  <style>
    body{
      background-image: url("assets/Imagenes/fondoTablero.png");
      background-repeat: no-repeat;
      background-size: cover;
      background-attachment: fixed;      
    }

    .tooltip-custom {
  position: absolute;
  background-color: #ffffff;
  color: #222;
  border: 2px solid #b3d9ff;
  border-radius: 6px;
  padding: 10px 14px;
  font-size: 14px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.25);
  z-index: 9999;
  max-width: 320px;
  opacity: 0;
  transform: translateY(-10px);
  transition: opacity 0.2s ease, transform 0.2s ease;
  pointer-events: none;
}

.tooltip-custom.show {
  opacity: 1;
  transform: translateY(0);
  pointer-events: auto; /* <--- activa eventos solo cuando se muestra */
}
  </style>
</head>
<body class="img-fluid bg-no-repeat">

  
  <nav class="navbar navbar-dark bg-dark ">
    <div class="container-fluid">
      <span class="navbar-brand mb-0 h1">Drafto Craft - APP de Seguimiento</span>
      <button type="button" id="abandonar" class="btn btn-outline-danger my-2 my-sm-0">Abandonar Partida</button>
    </div>
  </nav>

  <div class="container">
     <div class="d-flex justify-content-center align-items-start my-4">
    <div class="row g-4 w-100" style="max-width: 900px;">
    
    <!-- Selección de tablero (izquierda) -->
    <div class="col-md-6">
      <div class="text-center">
        <h5 class="mb-3 text-white">Seleccionar tablero de:</h5>
        <div id="tableroJug"  class="d-flex flex-wrap gap-2 justify-content-center">
          <?php foreach ($_SESSION["jugadores"] as $jugador): ?>
            <button data-apodo=<?=$jugador?> class="btn btn-sm btn-outline-primary"><?= htmlspecialchars($jugador) ?></button>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <!-- Jugador Activo (derecha) -->
    <div class="col-md-6">
      <div class="text-center">
        <h5 class="mb-3 text-white">Lanzador del dado</h5>
        <div id="activoJug" class="d-flex flex-wrap gap-2 justify-content-center">
          <?php foreach ($_SESSION["jugadores"] as $jugador): ?>
            <button data-apodo=<?=$jugador?> class="btn btn-sm btn-outline-primary"><?= htmlspecialchars($jugador) ?></button>
          <?php endforeach; ?>
        </div>
      </div>
    </div>   
  </div>
</div>

    <!-- Imagen del tablero--> 
    <div id="tooltip" class="tooltip-custom"></div>
    <div class="text-center mb-4">
      <h4 class="mb-3 text-white">Tu Tablero</h4>
      <div id="tablero" class="position-relative rounded p-3">
        <img src="assets/Imagenes/Tablero.jpg" class="img-fluid rounded shadow tablero-img" alt="Tablero de Draftosaurus" />

        <div id="equivalencia" class="recinto equivalencia" data-tooltip-title="La mina de la equivalencia" data-tooltip-text="Este recinto solo puede albergar <strong>mods de la misma especie</strong> y debe completarse de izquierda a derecha sin dejar espacios. Otorga puntos según la cantidad de mobs en él.">
          
        </div>

        <div id="triada" class="recinto triada" data-tooltip-title="La cabaña de la tríada" data-tooltip-text="Este recinto puede albergar hasta <strong>3 mobs sin importar su especie</strong>. Al final de la partida, ganas 7 puntos si hay exactamente 3 mobs en él. De lo contrario, obtienes 0 puntos.">
       
        </div>

        <div id="amor" class="recinto amor" data-tooltip-title="El páramo del amor" data-tooltip-text="Se pueden colocar <strong>todas las especies de mobs</strong>. Obtienes 5 puntos por cada pareja de la misma especie en este recinto. Está permitido tener más de una pareja de la misma especie. Los dinosaurios que no formen pareja no suman puntos. ">
          
        </div>
        
        <div id="rey" class="recinto rey" data-tooltip-title="La fosa del rey" data-tooltip-text="Sólo puede albergar <strong>un mobs</strong>. Obtienes 7 puntos si ningún jugador tiene en su parque más mobs que tú de esta especie. En caso de empate recibes igualmente los 7 puntos.">
        
        </div>

        <div id="diferencia" class="recinto diferencia" data-tooltip-title="El pulgatorio de la diferencia" data-tooltip-text="Sólo puede albergar <strong>mobs de especies distintas</strong>. Debe completarse de izquierda a derecha sin dejar espacios. Otorga puntos según la cantidad de mobs en él.">
          
        </div>
        
        <div id="soledad" class="recinto soledad" data-tooltip-title="El templo de la soledad" data-tooltip-text="Sólo puede albergar <strong>un mobs</strong>. Obtienes 7 puntos si es el único mobs de su especie en todos los recintos de tu tablero. De lo contrario obtienes 0 puntos.">
         
        </div>

        <div id="rio" class="recinto rio" data-tooltip-title="El río infernal" data-tooltip-text="El río es una zona especial que no cuenta como un recinto. Otorga <strong>1 punto</strong> por cada mobs en él. Simpre puedes colocar un mobs aquí, sin importar el resultado del dado ."></div>
      </div>
    </div>

    <!--Recintos-->


    <!-- Mobs disponibles -->
  <h5 class="mb-4 text-white text-center">Mobs Disponibles</h5>
  <div id="dinosaurios" class="d-flex flex-wrap gap-2 justify-content-center">
    <img src="assets/Fichas/piglin.png" id="piglin" class="dino-img"/>
    <img src="assets/Fichas/enderman.png" id="enderman" class="dino-img" />
    <img src="assets/Fichas/magma.png" id="magma" class="dino-img" />
    <img src="assets/Fichas/creeper.png" id="creeper" class="dino-img" />
    <img src="assets/Fichas/bruja.png" id="bruja" class="dino-img" />
    <img src="assets/Fichas/zombie.png" id="zombie" class="dino-img" />
  </div>

<!-- Dado del juego -->
  <h5 class="mb-4 mt-4 text-center text-white">Caras del Dado</h5>
  <div id="dados" class="justify-content-center gap-4 text-center mb-5">
    <img src="assets/Imagenes/Aldea.png" id="aldea" class="dado-img"/>
    <img src="assets/Imagenes/Minas.png" id="minas" class="dado-img"/>
    <img src="assets/Imagenes/Nether.png" id="nether" class="dado-img"/>
    <img src="assets/Imagenes/OverWorld.png" id="overWorld" class="dado-img"/>
    <img src="assets/Imagenes/SinCreeper.png" id="sinCreeper" class="dado-img"/>
    <img src="assets/Imagenes/SinMobs.png" id="sinMobs" class="dado-img"/>
  </div>

    <!-- Botones -->
    <div class="text-center mb-4 d-flex justify-content-center gap-2">
      <a href="index.php?ruta=reglas" class="btn btn-outline-secondary" target="blank">Reglas</a>
      <button id="finPartida" class="btn btn-danger ">Finalizar Partida</button>
    </div>

  </div>

  <div class="modal fade" id="AbandonarPartida" tabindex="-1" aria-labelledby="modalAbandonarPartidaLabel" aria-hidden="true" >
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-danger text-white">
        <h5 class="modal-title">Confirmar eliminación</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body">
        <p>¿Desea abandonar la partida?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
        <a href="index.php?ruta=limpiarDatos" class="btn btn-danger">Sí</a>
      </div>
    </div>
  </div>
</div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    const JUGADORES = <?php echo json_encode($_SESSION["jugadores"]); ?>;
  </script>
  <script>
    const modal = new bootstrap.Modal('#AbandonarPartida');
    const btnAbrir = document.getElementById('abandonar');
    btnAbrir.addEventListener('click', () => modal.show());
  </script>
  <script src="js/drag&drop.js"></script>
  <script src="js/cargarTablero.js"></script>
  <script src="js/tooltip.js"></script>
</body>
</html>
