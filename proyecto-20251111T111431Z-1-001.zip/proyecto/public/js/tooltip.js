const tooltip = document.getElementById('tooltip');
let tooltipTimeout = null; // guardará el timeout

function showTooltip(el) {
  const { tooltipTitle, tooltipText } = el.dataset;
  tooltip.innerHTML = `<h5>${tooltipTitle}</h5><p>${tooltipText}</p>`;
  tooltip.classList.add('show');

  const rect = el.getBoundingClientRect();
  tooltip.style.left = `${rect.left + rect.width / 2 + window.scrollX}px`;
  tooltip.style.top = `${rect.top + window.scrollY - tooltip.offsetHeight - 10}px`;
  tooltip.style.transform = 'translateX(-50%)';
}

function hideTooltip() {
  tooltip.classList.remove('show');
  if (tooltipTimeout) {
    clearTimeout(tooltipTimeout); // cancela cualquier timeout pendiente
    tooltipTimeout = null;
  }
}

// Aplicamos a todos los recintos con tooltip
document.querySelectorAll('[data-tooltip-title][data-tooltip-text]').forEach(el => {
  el.addEventListener('mouseenter', () => {
    // Esperar 1 segundo antes de mostrar
    tooltipTimeout = setTimeout(() => {
      showTooltip(el);
      tooltipTimeout = null; // limpiar
    }, 1000);
  });

  el.addEventListener('mouseleave', hideTooltip); // si sale antes, no se muestra
});
