<?php

class LoginRequest {
  private string $apodo;
  private string $clave;

  public function __construct(string $apodo, string $clave) {
    $this->apodo = $apodo;
    $this->clave = $clave;
  }

  public function getApodo(): string {
    return $this->apodo;
  }

  public function getClave(): string {
    return $this->clave;
  }

}