<?php

class PuntosController {

    public function puntos() {
        header("Content-Type: application/json");
        $tableros = json_decode($_POST["tableros"], true);
        $puntaje = [];

        foreach ($tableros as $nombreJugador => $tablero) {
            $puntaje[$nombreJugador] = $this->calcularPuntosTotales($tableros, $tablero, $nombreJugador);
        }

        echo json_encode($puntaje);
    }

    private function calcularPuntosTotales(array $tableros, array $tablero, string $nombreJugador): int {
        $puntos = 0;
        $puntos += $this->calcularPuntosRecintos($tablero);
        
        if (!empty($tablero["rey"])) {
            $puntos += $this->puntosRey($tableros, $tablero["rey"][0], $nombreJugador);
        }
        
        $puntos += $this->puntosCreeper($tablero);
        return $puntos;
    }

    private function calcularPuntosRecintos(array $tablero): int {
        $puntos = 0;

        $puntos += [0,2,4,8,12,18,24][count($tablero["equivalencia"] ?? [])];
        $puntos += [0,1,3,6,10,15,21][count($tablero["diferencia"] ?? [])];

        $puntos += (count($tablero["triada"] ?? []) === 3) ? 7 : 0;

        $puntos += count($tablero["rio"] ?? []);

        if (!empty($tablero["soledad"])) {
            $puntos += $this->validarSoledad($tablero) ? 7 : 0;
        }

        if (!empty($tablero["amor"])) {
            $puntos += array_sum(array_map(
                fn($cant) => floor($cant / 2) * 5,
                array_count_values($tablero["amor"])
            ));
        }
        return $puntos;
    }

    private function validarSoledad(array $tablero): bool {
        $figuraSoledad = $tablero["soledad"][0];
        
        foreach ($tablero as $recinto => $figuras) {
            if ($recinto !== "soledad" && in_array($figuraSoledad, $figuras)) {
                return false;
            }
        }     
        return true;
    }

    private function puntosCreeper(array $tablero): int {
        return count(array_filter($tablero, fn($recinto) => in_array("creeper", $recinto)));
    }

    private function contarFigura(array $tablero, string $figura): int {
        $total = 0;
        
        foreach ($tablero as $recinto) {
            $conteo = array_count_values($recinto);
            $total += $conteo[$figura] ?? 0;
        }   
        return $total;
    }

    private function puntosRey(array $tableros, string $figuraRey, string $nombreJugador): int {
        $jugadoresRey = array_map(
            fn($tablero) => $this->contarFigura($tablero, $figuraRey),
            $tableros
        );
        $maxCantidad = max($jugadoresRey);
        return ($jugadoresRey[$nombreJugador] === $maxCantidad) ? 7 : 0;
    }
}