<?php

require_once __DIR__ . '/../model/PartidaDAO.php';
require_once __DIR__ . '/../model/TableroDAO.php';
require_once __DIR__ . '/../model/JugadorDAO.php';

class TableroController {
    
  public function iniciarPartida() {

    if(!isset($_SESSION["jugadores"])){
      header("Location: index.php?ruta=salaEspera");
      exit;
    }

    if(!isset($_SESSION["idPartida"])){
      $horaActual = date('Y-m-d H:i:s');
        
      $idPartida = (new PartidaDAO())->crear($horaActual);
      $_SESSION['idPartida'] = $idPartida;

      $this->crearJugador($idPartida);        
      $this->tableros();
    }
    require_once __DIR__ . '/../view/tablero.php';
  }

  private function crearJugador($idPartida){
    $jugadorDAO = new JugadorDAO();
    foreach($_SESSION["jugadores"] as $jugador){
      $jugadorDAO->insertar($jugador, $idPartida);
    }
  }

  private function tableros(){
    $tablero = new TableroDAO();
    foreach($_SESSION["jugadores"] as $jugador){
      for($i=1;$i<=7;$i++){
        $tablero->crearTablero($i,$jugador,$_SESSION['idPartida']);
      }
    }    
  }
}