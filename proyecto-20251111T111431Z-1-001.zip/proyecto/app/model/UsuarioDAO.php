<?php

require_once 'Usuario.php';
require_once __DIR__ . '/../controller/LoginRequest.php';
require_once 'conexionDB.php';

class UsuarioDAO {

  private PDO $conn;

  public function __construct() {
    $this->conn = Conexion::getInstancia()->getConexion();
    // Establece el modo de error para que PDO lance excepciones en caso de fallo.
    $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  }

  public function crearUsuario(Usuario $usuario){
    try {
    	$sql = "INSERT INTO usuario (apodo, contra, email) VALUES (:apodo, :contra, :email)";
      $stmt = $this->conn->prepare($sql);

      // Bind de los parámetros con sus valores.
      $stmt->bindValue(':apodo', $usuario->getApodo());
      $stmt->bindValue(':contra', $usuario->getContrasena());
      $stmt->bindValue(':email', $usuario->getEMail());

      $stmt->execute();
    } catch (PDOException $e) {
      error_log("Error al insertar usuario: " . $e->getMessage());
      return false;
    }
  }

  public function consultarUsuario(string $apodo): string { 
    try {
      $sql = "SELECT email FROM usuario WHERE apodo = :apodo";
      $stmt = $this->conn->prepare($sql);
      $stmt->bindValue(':apodo', $apodo);
      $stmt->execute();

      $row = $stmt->fetch(PDO::FETCH_ASSOC);

      if ($row) {
        return $row['email'];
      }

      return "";
    } catch (PDOException $e) {
      error_log("Error al buscar usuario: " . $e->getMessage());
      return null;
    }
  }

	public function modificarUsuario(string $apodo, string $email): bool{
		try{
			$sql = "UPDATE usuario SET email = :email WHERE apodo = :apodo";
			$stmt = $this->conn->prepare($sql);
			$stmt->bindValue(':email',$email);
			$stmt->bindValue(':apodo',$apodo);
			return $stmt->execute();
		}catch(PDOException $e){
			error_log("Error al eliminar usuario: " . $e->getMessage());
      return false;
		}
	}

  public function eliminarUsuario(string $apodo){
		try{
			$sql = "UPDATE usuario SET cuenta = 0 WHERE apodo = :apodo";
			$stmt = $this->conn->prepare($sql);
			$stmt->bindValue(':apodo',$apodo);
			$stmt->execute();
		}catch(PDOException $e){
			error_log("Error al eliminar usuario: " . $e->getMessage());
      return false;
		}
  }

  public function iniciarSesion(LoginRequest $login): bool { 
    try {
      $sql = "SELECT contra FROM usuario WHERE apodo = :apodo AND cuenta = 1";
      $stmt = $this->conn->prepare($sql);
      $stmt->bindValue(':apodo', $login->getApodo());
      $stmt->execute();

      $row = $stmt->fetch(PDO::FETCH_ASSOC);

      if (!$row) {
        return false;
      }

    	return password_verify($login->getClave(),$row["contra"]);
    }catch (PDOException $e) {
      error_log("Error al buscar usuario: " . $e->getMessage());
      return false;
    }
  }
}