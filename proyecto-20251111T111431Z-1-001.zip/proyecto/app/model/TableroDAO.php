<?php

require_once "conexionDB.php";

class TableroDAO{
  private PDO $conn;

  public function __construct(){
    $this->conn = Conexion::getInstancia()->getConexion();
    $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  }

  public function crearTablero($idRecinto,$apodo,$idPartida){
    try{
      $sql = "INSERT INTO tablero (idRecinto,apodo,idPartida) VALUES (:idRecinto, :apodo, :idPartida)";
      $stmt = $this->conn->prepare($sql);

      $stmt->bindValue(":idRecinto",$idRecinto);
      $stmt->bindValue(":apodo",$apodo);
      $stmt->bindValue(":idPartida",$idPartida);
      $stmt->execute();

    }catch(PDOException $e){
      error_log("Error al buscar usuario: " . $e->getMessage());
    }
  }
}