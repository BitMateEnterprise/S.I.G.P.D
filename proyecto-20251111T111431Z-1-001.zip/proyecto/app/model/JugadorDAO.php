<?php
require_once 'conexionDB.php';
require_once __DIR__ . '/../controller/Estadisticas.php';

class JugadorDAO{
  private PDO $conn;

  public function __construct() {
    $this->conn = Conexion::getInstancia()->getConexion();
    // Establece el modo de error para que PDO lance excepciones en caso de fallo.
    $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  }

  public function insertar($jugador,$idPartida){
    try{
      $sql = "INSERT INTO participante (apodo,idPartida) VALUES (:apodo,:idPartida)";
      $stmt = $this->conn->prepare($sql);
      $stmt->bindValue(":apodo", $jugador);
      $stmt->bindValue(":idPartida", $idPartida);

      $stmt->execute();
    }catch(PDOExecption $e){
      error_log("Error al buscar usuario: " . $e->getMessage());
    }  
  }

  public function puntos($apodo,$puntos,$idPartida){
    try{
      $sql = "UPDATE participante SET puntos = :puntos WHERE apodo = :apodo AND idPartida = :idPartida";
      $stmt = $this->conn->prepare($sql);
      $stmt->bindValue(":puntos", $puntos);
      $stmt->bindValue(":apodo", $apodo);
      $stmt->bindValue(":idPartida", $idPartida);

      $stmt->execute();

    }catch(PDOExecption $e){
      error_log("Error al buscar usuario: " . $e->getMessage());
    }
  }

  public function ganador($apodo,$idPartida){
    try{
      $sql = "UPDATE participante SET ganador = 1 WHERE apodo = :apodo AND idPartida = :idPartida";
      $stmt = $this->conn->prepare($sql);
      $stmt->bindValue(":apodo", $apodo);
      $stmt->bindValue(":idPartida", $idPartida);

      $stmt->execute();

    }catch(PDOExecption $e){
      error_log("Error al buscar usuario: " . $e->getMessage());
    }
  }

  private function getPuntaje($apodo): int{
    try{
      $sql = "SELECT sum(puntos) puntos FROM participante WHERE apodo = :apodo";
      $stmt = $this->conn->prepare($sql);

      $stmt->bindValue(':apodo', $apodo);
      $stmt->execute();

      $puntos = $stmt->fetch(PDO::FETCH_ASSOC);
      if($puntos["puntos"] == NULL){
        $puntos["puntos"] = 0;
      }
      return $puntos["puntos"];

    }catch (PDOException $e) {
      error_log("Error al buscar usuario: " . $e->getMessage());
      return null;
    }   
  }

  private function getPartidasJugadas($apodo): int{
    try{
      $sql = "SELECT count(*) partidas FROM participante WHERE apodo = :apodo";
      $stmt = $this->conn->prepare($sql);

      $stmt->bindValue(':apodo', $apodo);
      $stmt->execute();

      $partidas = $stmt->fetch(PDO::FETCH_ASSOC);
      return $partidas["partidas"];

    }catch (PDOException $e) {
      error_log("Error al buscar usuario: " . $e->getMessage());
      return null;
    }   
  }

  private function getPartidasGanadas($apodo): int{
    try{
      $sql = "SELECT count(*) partidas FROM participante WHERE apodo = :apodo and ganador = 1";
      $stmt = $this->conn->prepare($sql);

      $stmt->bindValue(':apodo', $apodo);
      $stmt->execute();

      $partidas = $stmt->fetch(PDO::FETCH_ASSOC);
      return $partidas["partidas"];

    }catch (PDOException $e) {
      error_log("Error al buscar usuario: " . $e->getMessage());
      return null;
    }   
  }

  private function ranking(): array{
    try{
      $sql = "SELECT apodo,sum(puntos) puntos FROM participante GROUP BY apodo ORDER BY puntos DESC LIMIT 5";

      $stmt = $this->conn->query($sql);
      $ranking = [];
      
      return $stmt->fetchAll(PDO::FETCH_ASSOC);
      
    }catch(PDOException $e) {
      error_log("Error al buscar usuario: " . $e->getMessage());
      return null;
    }
  }

  public function getEstadisticas($apodo): Estadisticas{
    $puntaje = $this->getPuntaje($apodo);
    $partidasJugadas = $this->getPartidasJugadas($apodo);
    $partidasGanadas = $this->getPartidasGanadas($apodo);
    $ranking = $this->ranking();

    return new Estadisticas($puntaje, $partidasJugadas, $partidasGanadas, $ranking);
  }
}
?>