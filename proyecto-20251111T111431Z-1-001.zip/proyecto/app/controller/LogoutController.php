<?php

class Logout{
  public function logout(){
    $_SESSION = [];
    session_destroy();
    echo "<script>
      localStorage.clear();
      window.location.href = 'index.php?ruta=inicio';
    </script>";
    exit();
  }
}