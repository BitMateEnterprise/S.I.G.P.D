<?php

require_once "conexionDB.php";
class PartidaDAO{
  private PDO $conn;

  public function __construct() {
    $this->conn = Conexion::getInstancia()->getConexion();
    // Establece el modo de error para que PDO lance excepciones en caso de fallo.
    $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  }

  public function crear($hcomienzo){
    try{
      $sql = "INSERT INTO partida (hcomienzo) VALUES (:hcomienzo)";
      $stmt = $this->conn->prepare($sql);

      $stmt->bindValue(":hcomienzo",$hcomienzo);
      $stmt->execute();
      return (int)$this->conn->lastInsertId();
    }catch (PDOException $e) {
      error_log("Error al buscar usuario: " . $e->getMessage());
      return null;
    } 
  }

  public function fin($hfinal,$idPartida){
    try{
      $sql = "UPDATE partida SET hfinal = :hfinal WHERE idPartida = :idPartida";
      $stmt = $this->conn->prepare($sql);

      $stmt->bindValue(":hfinal",$hfinal);
      $stmt->bindValue(":idPartida",$idPartida);
      $stmt->execute();
    }catch (PDOException $e) {
      error_log("Error al buscar usuario: " . $e->getMessage());
      return null;
    } 
  }

}