<?php
class JugadorController{
  public function crearJugadores(){
    $_SESSION['jugadores'] = [];
  }

  public function agregarJugador($apodo){
    if(!in_array($apodo, $_SESSION['jugadores'], true)) {
      $_SESSION['jugadores'][] = $apodo;
    }
  } 
  
  public function eliminarJugador($jugador){
    if($jugador !== $_SESSION["usuario"]){
    $posicion = array_search($jugador,$_SESSION['jugadores']);
    unset($_SESSION['jugadores'][$posicion]);
    $_SESSION['jugadores'] = array_values($_SESSION['jugadores']); 
  }
  }
}