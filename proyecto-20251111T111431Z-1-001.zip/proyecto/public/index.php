<?php

session_start();
//session_destroy();
require_once __DIR__ . '/../app/controller/UsuarioController.php';
$usuario = new UsuarioController();

$ruta = $_GET['ruta'] ?? 'inicio'; // ?? operador de fusión nula. Luego de PHP 7

switch ($ruta) {
	case 'inicio':
		require_once __DIR__ . '/../app/view/inicio.php';
		break;

	case 'login':
    if(isset($_GET["redirigir"]) && count($_SESSION["jugadores"]) >= 5){
        $_SESSION["mensaje_sala"] = "El máximo de jugadores es 5.";
        header("Location: index.php?ruta=salaEspera");
        exit;
    }

		if(isset($_SESSION["idPartida"])){
			header("Location: index.php?ruta=tablero");
      exit;
		}

    if(isset($_SESSION["usuario"])){
        if(isset($_GET["redirigir"])){
            $_SESSION["redireccion"] = $_GET["redirigir"];
        }
    }	

    require_once __DIR__ . '/../app/controller/LoginController.php';
    $loginController = new LoginController();
    $loginController->login();
    break;

	case 'logout':
		if (!isset($_SESSION['usuario'])){
			header("Location: index.php?ruta=login");
			exit;
		}
		
		require_once __DIR__ . '/../app/controller/LogoutController.php';
		(new Logout())->logout();

		break;

	case 'perfil':		
		if(isset($_SESSION["usuario"])){
			require_once __DIR__ . '/../app/view/perfil.php';
		}else{
			header("Location: index.php?ruta=login");
			exit;
		}
		break; 	

	case 'obtener':    		
		$usuario->obtenerUsuario($_GET['apodo']);     
		break;
	
	case 'actualizarDatos':
		$usuario->modificarDatos();
		break;
			
	case 'registro':
		require_once __DIR__ . '/../app/controller/RegistroController.php';
		(new RegistroController())->registro();
		break;

	case 'eliminarCuenta':
		$usuario->eliminarCuenta();
		break;

	case 'salaEspera':
		if(isset($_SESSION["idPartida"])){
			header("Location: index.php?ruta=tablero");
      exit;
		}

		require_once __DIR__ . '/../app/controller/SalaController.php';
		(new SalaEspera())->prepararPartida();
		break;

	case 'eliminarJug':
		require_once __DIR__ . '/../app/controller/JugadorController.php';
		(new JugadorController())->eliminarJugador($_GET["jugador"]);
		header("Location: index.php?ruta=salaEspera");
		exit;
		break;		
		
	case 'tablero':		
		require_once __DIR__ . '/../app/controller/TableroController.php';
		$tableroController = new TableroController();
    $tableroController->iniciarPartida();
		break;       

	case 'finPartida':
		require_once __DIR__ . '/../app/controller/PuntosController.php';
		(new PuntosController())->puntos();
		break;
		
	case 'resultados': 
		if(!isset($_SESSION["resultados"])){ 
			header("Location: index.php?ruta=inicio");
		}	
    require_once __DIR__ . '/../app/view/FinPartida.php';
    break;

	case 'limpiarDatos':
		require_once __DIR__ . '/../app/controller/FinController.php';
		(new FinPartida())->limpiarSesion();
		break;	
    
	case 'reglas':   
    require_once __DIR__ . '/../app/view/Reglas.html';
    break;	
		
	default:
		echo '<h1>Error 404</h1>';
		break;
}