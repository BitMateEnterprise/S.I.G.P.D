<?php

require_once "conexionDB.php";
require_once "Colocacion.php";

class ColocacionDAO{
  private PDO $conn;
  
  public function __construct(){
    $this->conn = Conexion::getInstancia()->getConexion();
    $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  }

  public function insertar(Colocacion $colocacion){
    try{
      $sql = "INSERT INTO colocacion (idRecinto, apodo, idPartida,idFigura) VALUES (:idRecinto,:apodo,:idPartida,:idFigura)";
      $stmt = $this->conn->prepare($sql);

      $stmt->bindValue(":idRecinto", $colocacion->getIdRecinto());
      $stmt->bindValue(":apodo", $colocacion->getApodo());
      $stmt->bindValue(":idPartida", $colocacion->getIdPartida());
      $stmt->bindValue(":idFigura", $colocacion->getIdFigura());

      $stmt->execute();
    }catch(PDOException $e){
      error_log("Error al buscar usuario: " . $e->getMessage());
      throw $e;
    }
  }
}