<?php

require_once "conexionDB.php";

class FiguraDAO{
  private PDO $conn;

  public function __construct(){
    $this->conn = Conexion::getInstancia()->getConexion();
    $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  }

  public function getFigura(){
    try{
      $sql = "SELECT idFigura, nombre FROM figura";
      $stmt = $this->conn->query($sql);

      $figuras = [];
      while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        $figuras[$row["nombre"]] = $row["idFigura"];
      }
      return $figuras;

    }catch(PDOException $e){
      error_log("Error al buscar usuario: " . $e->getMessage());
    }
  }
}