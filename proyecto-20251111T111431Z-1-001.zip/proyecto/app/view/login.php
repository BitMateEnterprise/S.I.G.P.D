<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login - Drafto Craft</title>
  <link rel="icon" type="image/png" href="assets/Imagenes/Logo.png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body{
      background-image: url("assets/Imagenes/fondoTablero.png");
      background-repeat: no-repeat;
      background-size: cover;
      background-attachment: fixed;      
    }
  </style>
</head>
<body class="d-flex justify-content-center align-items-center vh-100" style="background-color: #fff9c4;">

  <div class="bg-light p-4 rounded shadow" style="width: 350px;">
    <h2 class="text-center mb-4">Iniciar Sesión</h2>
    <form action="index.php?ruta=login" method="POST" id="enviarDatos">

   <p id='mensaje' class=text-center style=color:red>
    <?php
      if(isset($mensaje)){
        echo htmlspecialchars($mensaje);
      }
    ?>
    </p><br>

      <div class="mb-3">
        <label for="usuario" class="form-label">Usuario</label>
        <input type="text" class="form-control" id="usuario" name="apodo" required>
      </div>

      <div class="mb-3">
        <label for="clave" class="form-label">Contraseña</label>
        <input type="password" class="form-control" id="clave" name="clave" required>
      </div>
      <button type="submit" class="btn btn-primary w-100">Entrar</button>
      <a href="index.php?ruta=registro" class="btn btn-outline-success w-100 mt-2">Registrarse</a>
    </form>
  </div>

  <script src="js/validarLogin.js"></script>
</body>
</html>
