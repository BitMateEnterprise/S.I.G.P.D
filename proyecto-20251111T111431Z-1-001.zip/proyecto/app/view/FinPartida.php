<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Fin de Partida - Drafto Craft</title>
  <link rel="icon" type="image/png" href="assets/Imagenes/Logo.png">
  <link rel="stylesheet" href="../public/css/finPartida.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>

</head>
<body style="background-color: #fff9c4;" class="d-flex justify-content-center align-items-center vh-100">

  <div id="contenidoPrincipal" class="text-center border rounded p-4 shadow" style="width: 90%; max-width: 400px; background-color: rgba(200, 200, 200, 0.3);">

    <!-- Logo -->
    <img src="assets/Imagenes/Logo.png" alt="Logo Drafto Craft" class="img-fluid mb-3" style="max-height: 120px;">

    <!-- Título -->
    <h2 class="mb-3">¡Fin de la Partida!</h2>

    <!-- Puntuaciones -->
    <div class="mb-4">
      <p class="mb-1">Resultados finales:</p>
      <ul class="list-group">
        <?php 
        $resultados = $_SESSION['resultados'] ?? [];
        $emojis = ['🏆', '⭐', '💀', '🎮', '🎯'];
        $index = 0;
        
        foreach($resultados as $jugador => $puntos): 
        ?>
          <li class="list-group-item d-flex justify-content-center align-items-center position-relative">
            <span class="fw-bold"><?= htmlspecialchars($jugador) ?></span>
            <span class="position-absolute end-0 me-3">
              <?= $puntos ?> <?= $emojis[$index] ?? '🎮' ?>
            </span>
          </li>
        <?php 
        $index++;
        endforeach; 
        ?>
      </ul>
    </div>

    <p class="text-muted mb-4">¡Gracias por jugar a Drafto Craft!</p>
    <a href="index.php?ruta=limpiarDatos" class="btn btn-success w-100">Volver al Perfil</a>
  </div>

  <!-- Modal del Ganador -->
  <div id="modalGanador" style="display: flex; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.84); z-index: 9999; justify-content: center; align-items: center;">
    <div style="text-align: center;">
      <p class="texto-ganador"><?=array_key_first($_SESSION["resultados"])?></p>
      <script src="https://unpkg.com/@lottiefiles/dotlottie-wc@0.8.1/dist/dotlottie-wc.js" type="module"></script>
      <dotlottie-wc 
        id="animacionGanador"
        src="https://lottie.host/9ef9c9ad-b46f-4654-bafd-3dcb11cff121/anZwfErV8q.lottie" 
        style="width: 350px; height: 350px;" 
        autoplay>
      </dotlottie-wc>  
    </div>
  </div>

  <script>
    window.addEventListener('DOMContentLoaded', () => {
      const modal = document.getElementById('modalGanador');
      const contenido = document.getElementById('contenidoPrincipal');
      
      modal.style.transition = 'opacity 0.5s ease';
      
      // Esperar 6 segundos (animación completa)
      setTimeout(() => {
        // Fade out del modal
        modal.style.opacity = '0';
        
        setTimeout(() => {
          modal.style.display = 'none';
          
          // Esperar 1 segundo adicional antes de mostrar el contenido
          setTimeout(() => {
            contenido.classList.add('mostrar');
          }, 1000);
          
        }, 500); // Tiempo de transición del fade out
      }, 6000);
    });
  </script>

</body>
</html>