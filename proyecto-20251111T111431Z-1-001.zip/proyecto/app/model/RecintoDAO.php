<?php

require_once "conexionDB.php";

class RecintoDAO{
  private PDO $conn;

  public function __construct(){
    $this->conn = Conexion::getInstancia()->getConexion();
    $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  }

  public function getRecinto(){
    try{
      $sql = "SELECT idRecinto, nombre FROM recinto";
      $stmt = $this->conn->query($sql);

      $recintos = [];
      while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        $recintos[$row["nombre"]] = $row["idRecinto"];
      }
      return $recintos;

    }catch(PDOException $e){
      error_log("Error al buscar usuario: " . $e->getMessage());
    }
  }
}