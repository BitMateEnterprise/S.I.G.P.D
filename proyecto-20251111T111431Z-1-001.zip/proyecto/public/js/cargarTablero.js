function cargarTableroJugador(nombreJugador) {
  TODOS_RECINTOS.forEach(recinto => {
    document.getElementById(recinto).innerHTML = '';
  });

  const datosJugador = localStorage.getItem(nombreJugador);
  if (!datosJugador) return;

  let tableroJugador;
  tableroJugador = JSON.parse(datosJugador);

  // 4. Por cada recinto, crear y añadir las imágenes
  for (const [recinto, figuras] of Object.entries(tableroJugador)) {
    const contenedor = document.getElementById(recinto);
    if (!contenedor) continue;

    figuras.forEach(figura => {
      const clon = document.getElementById(figura).cloneNode(true);
      clon.removeAttribute("id");
      clon.draggable = false;
      clon.addEventListener("dblclick", () => {
        clon.remove();
        borrarFigura(recinto, figura);
      });

      contenedor.appendChild(clon);
    });
  }
}

document.getElementById('tableroJug').addEventListener('click', function (e) {
  if (e.target.tagName === 'BUTTON') {
    const nombreJugador = e.target.getAttribute('data-apodo');
    cargarTableroJugador(nombreJugador);
  }
});