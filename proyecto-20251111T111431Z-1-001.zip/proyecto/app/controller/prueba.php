<?php
$input = array("red", "green", "blue", "yellow");
$valor=array_splice($input, 2);
//var_dump($input);
var_dump($valor);