<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Sala de Espera - Drafto Craft</title>
  <link rel="icon" type="image/png" href="assets/Imagenes/Logo.png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />

  <style>
    body{
      background-image: url("assets/Imagenes/fondoTablero.png");
      background-repeat: no-repeat;
      background-size: cover;
      background-attachment: fixed;      
    }
  </style>
</head>
<body style="background-color: #fff9c4;" class="d-flex justify-content-center align-items-center vh-100">

  <div class="text-center border rounded p-4 shadow bg-light" style="width: 90%; max-width: 400px;">

    <!-- Logo -->
    <img src="assets/Imagenes/Logo.png" alt="Logo Drafto Craft" style="max-height: 120px;">

    <!-- Título -->
    <h2 class="mb-3">Sala de Espera</h2>

    <p id='mensaje' class=text-center style=color:red>
    <?php
      if(isset($mensaje)){
        echo htmlspecialchars($mensaje);
      }
    ?>
    </p><br>

    <!-- Lista de jugadores -->
    <div class="mb-4">
      <p class="mb-1">Lista de jugadores:</p>
      <ul class="list-group">
        <?php foreach ($_SESSION["jugadores"] as $jugador): ?>
            <li class="list-group-item d-flex justify-content-center align-items-center position-relative"><?= htmlspecialchars($jugador) ?>
            <a href="index.php?ruta=eliminarJug&jugador=<?=$jugador?>" class="btn btn-outline-danger btn-sm position-absolute end-0 me-2">X</a>
            </li>
            
          <?php endforeach; ?>
      </ul>
    </div>

    <div class="d-flex mb-3 justify-content-center gap-2">
        <a href="index.php?ruta=login&redirigir=salaEspera" class="btn btn-outline-success">Agregar jugador</a>
        
      </div>

    <!-- Mensaje de espera -->
    <!-- <p>Esperando a que se unan todos los jugadores...</p> -->

    <!-- Botones -->
    <div class="d-flex flex-column gap-2">
      <a href="index.php?ruta=tablero" class="btn btn-primary">Comenzar Partida</a>
      <a href="index.php?ruta=perfil" class="btn btn-outline-secondary">Volver al perfil</a>
    </div>

  </div>

</body>
</html>
