const TODOS_RECINTOS = ["equivalencia", "soledad", "diferencia", "rey", "rio", "amor", "triada"];
const restricciones = {
  "overWorld": ["equivalencia", "rey", "triada", "rio"],
  "nether": ["diferencia", "amor", "soledad", "rio"],
  "aldea": ["rey", "soledad", "diferencia", "rio"],
  "minas": ["equivalencia", "amor", "triada", "rio"],
  "sinCreeper": TODOS_RECINTOS,
  "sinMobs": TODOS_RECINTOS
};

let dadoSelect, tableroJug, tableroSelect, activoJug;
document.getElementById("dinosaurios").addEventListener("dragstart",arrastrarFigura);
document.getElementById("tableroJug").addEventListener("click", setJugadorTablero);
document.getElementById("activoJug").addEventListener("click", setJugadorActivo);
document.getElementById("dados").addEventListener("click", seleccionarDado);

function seleccionarDado(e){
  if (!e.target.classList.contains("dado-img")) return;

  if (dadoSelect) {
    dadoSelect.classList.remove("seleccionado");
    limpiarEventosRecintos()
  }

  dadoSelect = e.target;
  dadoSelect.classList.add("seleccionado");
  habilitarRecintos();
}

function limpiarEventosRecintos() {
  TODOS_RECINTOS.forEach(e => {
    const recinto = document.getElementById(e);   
    recinto.removeEventListener("dragover", dragover);
    recinto.removeEventListener("drop", drop);   
  });
}

function arrastrarFigura(e){
  if (!tableroSelect) return alert("Seleccione el tablero de un jugador");

  if (!activoJug) return alert("Seleccione al jugador que lanza el dado");

  if (e.target.classList.contains("dino-img")) e.dataTransfer.setData("id", e.target.id);
}

function tableroPropio(){
  return tableroJug && activoJug && (tableroJug === activoJug.dataset.apodo);
}

function habilitarRecintos() {
  let recintosPermitidos = tableroPropio() ? TODOS_RECINTOS : restricciones[dadoSelect.id];

  recintosPermitidos.forEach(elemento => {
    const recinto = document.getElementById(elemento);  
    recinto.addEventListener("dragover", dragover);
    recinto.addEventListener("drop", drop);  
  });
}

function dragover(evento) {
  evento.preventDefault();
}

function drop(evento) {
  let id = evento.dataTransfer.getData("id");
  let recinto = evento.currentTarget;
  const tablero = obtenerTablero();
  
  if(tableroCompleto(tablero)){
    alert("Ya colocaste las 12 figuras en el tablero");
    return;
  }  

  if (!colocacion(recinto.id, id, dadoSelect.id,tablero)) return;

  const figura = document.getElementById(id);
  const clon = figura.cloneNode(true);
  clon.removeAttribute("id");
  clon.draggable = false;
  clon.addEventListener("dblclick", () => {
    clon.remove();
    borrarFigura(recinto.id,id);
  });
  recinto.appendChild(clon);
}

function borrarFigura(recintoId, figuraId) {
  const tablero = obtenerTablero();  
  const index = tablero[recintoId].indexOf(figuraId);
  tablero[recintoId].splice(index, 1);
  localStorage.setItem(tableroJug, JSON.stringify(tablero)); 
}


function setJugadorTablero(evento) {
  if (evento.target.tagName !== "BUTTON") return;

  if (tableroSelect) {
    tableroSelect.classList.remove("btn-primary");
    tableroSelect.classList.add("btn-outline-primary");
  }  

  tableroSelect = evento.target
  tableroSelect.classList.remove("btn-outline-primary");
  tableroSelect.classList.add("btn-primary");
  tableroJug = tableroSelect.dataset.apodo;

  if(dadoSelect){
    limpiarEventosRecintos();
    habilitarRecintos();
  }
}

function setJugadorActivo(evento) {
  if (evento.target.tagName !== "BUTTON") return;

  if (activoJug) {
    activoJug.classList.remove("btn-primary");
    activoJug.classList.add("btn-outline-primary");
  }
  
  activoJug = evento.target
  activoJug.classList.remove("btn-outline-primary");
  activoJug.classList.add("btn-primary"); 
  
  if(dadoSelect){
    limpiarEventosRecintos();
    habilitarRecintos();
  }
}

function obtenerTablero(){
  return JSON.parse(localStorage.getItem(tableroJug)) || { equivalencia: [], diferencia: [], triada: [], rio: [], rey: [], soledad: [], amor: [] };
}

function colocacion(recinto, figura, dadoSelect,tablero) { 
  let colocacionDado = true;

  if(!tableroPropio()){
    if((dadoSelect === "sinMobs" || dadoSelect === "sinCreeper") && recinto !== "rio"){
      colocacionDado = validarDado(tablero,dadoSelect,recinto);
    }
  }

  if (colocacionDado) {
    if (validarRecinto(recinto, figura, tablero)) {
      tablero[recinto].push(figura);
      localStorage.setItem(tableroJug, JSON.stringify(tablero));
      return true;
    }
  }

  alert("Colocación inválida");
  return false;
}

function validarRecinto(recinto, figura, tablero) {
  switch (recinto) {
    case "equivalencia":
      return tablero[recinto].length === 0 || (tablero[recinto].length < 6 && tablero[recinto].includes(figura));

    case "diferencia":
      return tablero[recinto].length === 0 || !tablero[recinto].includes(figura);      

    case "triada":
      return tablero[recinto].length < 3;
  
    case "amor":
      return tablero[recinto].length < 6;       

    case "rio":
      return tablero[recinto].length < 12;
     
    case "rey":
      return tablero[recinto].length < 1;    

    case "soledad":
      return tablero[recinto].length < 1;       
  }
}

function validarDado(tablero,dadoSelect,recinto){
  switch(dadoSelect){
    case "sinMobs":
      return tablero[recinto].length === 0;
    
    case "sinCreeper":
      return !tablero[recinto].includes("creeper"); 
  }
}

document.getElementById("finPartida").addEventListener("click",enviarDatos);

async function enviarDatos(){
  const tableros = {};

  if(localStorage.length === 0){
    alert("No hay tableros guardados. Debes colocar las figuras primero.");
    return;
  }

  for(const apodo of JUGADORES){
    const tablero = JSON.parse(localStorage.getItem(apodo));

    if(!tablero){
      alert(`El jugador ${apodo} no ha colocado ninguna figura`);
      return;
    }

    if(!tableroCompleto(tablero)){ 
      alert(`El jugador ${apodo} no tiene 12 figuras`);
      return;
    }
    tableros[apodo] = tablero;
  }

  const formData = new FormData();
  formData.append("tableros", JSON.stringify(tableros));

  try{
    const respuesta = await fetch("index.php?ruta=finPartida",{
      method: "POST",
      body: formData
    });

    const resultado = await respuesta.json();

    if(resultado.exito){
      localStorage.clear();
      window.location.href= "index.php?ruta=resultados";
    }
    
  }catch(error){
    console.error("Error al enviar datos:", error);
  }
}

function tableroCompleto(tablero){
  const cantidad = Object.values(tablero).reduce((total,recinto) => total+recinto.length,0);
  return cantidad === 12;
}