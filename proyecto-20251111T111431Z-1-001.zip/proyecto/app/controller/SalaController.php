<?php

class SalaEspera{
  public function prepararPartida(){   
    if(!isset($_SESSION["usuario"])){
      header("Location: index.php?ruta=login");
      exit;
    }

    require_once __DIR__ . '/../controller/JugadorController.php';
    $jugadorController = new JugadorController();

    if(!isset($_SESSION["jugadores"])){
      $jugadorController->crearJugadores();
    }

    $jugadorController->agregarJugador($_SESSION["usuario"]);  
    
    $mensaje = isset($_SESSION['mensaje_sala']) ? $_SESSION['mensaje_sala'] : null;
    unset($_SESSION['mensaje_sala']);

    require_once __DIR__ . '/../view/SaladeEspera.php';
  }
}