<?php
class Usuario {
    private string $apodo;
    private string $contrasena;
    private string $eMail;

    public function __construct(string $apodo, string $contrasena, string $eMail) {
        $this->apodo = $apodo;
        $this->setContrasena($contrasena);
        $this->eMail = $eMail;
    }

    public function getApodo(): string {
        return $this->apodo;
    }

    public function setApodo(string $apodo): void {
        $this->apodo = $apodo;
    }

    public function getContrasena(): string {
        return $this->contrasena;
    }

    public function setContrasena(string $contrasena): void {
        $contrasena = password_hash($contrasena,PASSWORD_BCRYPT);
        $this->contrasena = $contrasena;
    }

    public function getEMail(): string {
        return $this->eMail;
    }

    public function setEMail(string $eMail): void {
        $this->eMail = $eMail;
    }
}