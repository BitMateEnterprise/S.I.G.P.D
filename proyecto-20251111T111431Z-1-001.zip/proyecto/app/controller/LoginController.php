<?php

class LoginController {

  public function login(){

  if($_SERVER["REQUEST_METHOD"] === "POST"){
    $apodo = trim($_POST["apodo"]) ?? "";
    $clave = trim($_POST["clave"]) ?? "";

    require_once 'ValidarEntradas.php'; 
    $mensaje = (new ValidarEntradas())->validarLogin($apodo,$clave);

    if($mensaje === null){  
    
    require_once 'LoginRequest.php';
    $login = new LoginRequest($apodo,$clave);

    require_once __DIR__ . '/../model/UsuarioDAO.php';

    $usuarioDAO = new UsuarioDAO();
    $usuarioLogueado = $usuarioDAO->iniciarSesion($login);

    if($usuarioLogueado){

      if(isset($_SESSION["redireccion"])){
        require_once 'JugadorController.php';
        (new JugadorController())->agregarJugador($apodo);
        unset($_SESSION["redireccion"]);
        header("Location: index.php?ruta=salaEspera");
        exit;
      }

    $_SESSION["usuario"] = $apodo;
    header("Location: index.php?ruta=perfil");
    exit;  
    
  }else{
    $mensaje = "Usuario o contraseña incorrecta";
  }
  }
}
require_once __DIR__ . '/../view/login.php';
}
}
?>
