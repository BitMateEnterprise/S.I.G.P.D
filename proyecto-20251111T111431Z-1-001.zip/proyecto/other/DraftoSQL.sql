CREATE DATABASE IF NOT EXISTS draftodb;
USE draftodb;

-- Tabla Usuario
CREATE TABLE `usuario`(
   `apodo` varchar(30) NOT NULL,
   `contra` varchar(255) NOT NULL,
   `email` varchar(55) NOT NULL,
   `cuenta` TINYINT(1) NOT NULL DEFAULT 1,

   PRIMARY KEY (`apodo`)
);

-- Tabla Partida
CREATE TABLE `partida`(
   `idPartida` int(11) NOT NULL AUTO_INCREMENT,
   `hcomienzo` datetime DEFAULT CURRENT_TIMESTAMP,
   `hfinal` datetime DEFAULT NULL,

   PRIMARY KEY (`idPartida`)
);

-- Tabla Participante
CREATE TABLE `participante`(
   `apodo` varchar(30) NOT NULL,
   `idPartida` int(11) NOT NULL,
   `puntos` int(11) DEFAULT 0,
   `ganador` BOOLEAN DEFAULT 0,

   PRIMARY KEY (`apodo`,`idPartida`),
   FOREIGN KEY (`apodo`) REFERENCES `usuario` (`apodo`),
   FOREIGN KEY (`idPartida`) REFERENCES `partida` (`idPartida`)
);

-- TABLA RECINTO
CREATE TABLE `recinto`(
   `idRecinto` int(11) NOT NULL AUTO_INCREMENT,
   `nombre` varchar(15) DEFAULT NULL,
   `descripcion` varchar(100) DEFAULT NULL,
   `limiteFigura` TINYINT DEFAULT NULL,

   PRIMARY KEY (`idRecinto`)
);

-- TABLA TABLERO
CREATE TABLE `tablero`(
   `idRecinto` int(11) NOT NULL,
   `apodo` varchar(30) NOT NULL, 
   `idPartida` int(11) NOT NULL,

   PRIMARY KEY (`apodo`,`idRecinto`,`idPartida`),
   FOREIGN KEY (`apodo`,`idPartida`) REFERENCES `participante` (`apodo`,`idPartida`),
   FOREIGN KEY (`idRecinto`) REFERENCES `recinto` (`idRecinto`)
);


-- TABLA FIGURA
CREATE TABLE `figura`(
   `idFigura` int(11) NOT NULL AUTO_INCREMENT,
   `nombre` varchar(20) DEFAULT NULL,
   `color` ENUM('amarillo', 'negro', 'rojo', 'verde', 'morado', 'azul') DEFAULT NULL,

   PRIMARY KEY (`idFigura`)
);

-- TABLA colocación
CREATE TABLE `colocacion`(
   `idColocacion` int(11) NOT NULL AUTO_INCREMENT,
   `idRecinto` int(11) NOT NULL,
   `apodo` varchar(30) NOT NULL,
   `idPartida` int(11) NOT NULL,
   `idFigura` int(11) NOT NULL,

   PRIMARY KEY (`idColocacion`),
   FOREIGN KEY (`apodo`,`idRecinto`,`idPartida`) REFERENCES `tablero` (`apodo`,`idRecinto`,`idPartida`),
   FOREIGN KEY (`idFigura`) REFERENCES `figura` (`idFigura`)
);

-- Insertar datos
-- Usuarios. Las contraseñas de los usuarios de prueba son "1234"
INSERT INTO `usuario` (apodo,contra,email) values ("cjx","$2y$10$3jiVi9442U6jWvA4oWuwMurv669QjjLIi2xGgOvU1gvFeAHRlWZWa","mesac@gmail.com");
INSERT INTO `usuario` (apodo,contra,email) values ("linus","$2y$10$3jiVi9442U6jWvA4oWuwMurv669QjjLIi2xGgOvU1gvFeAHRlWZWa","linus@gmail.com");
INSERT INTO `usuario` (apodo,contra,email) values ("python","$2y$10$3jiVi9442U6jWvA4oWuwMurv669QjjLIi2xGgOvU1gvFeAHRlWZWa","python@gmail.com");
INSERT INTO `usuario` (apodo,contra,email) values ("tux","$2y$10$3jiVi9442U6jWvA4oWuwMurv669QjjLIi2xGgOvU1gvFeAHRlWZWa","tux@gmail.com"); 

-- Partida
INSERT INTO `partida` (hcomienzo,hfinal) VALUES ("2025-09-15 10:30:00","2025-09-15 10:40:00");
INSERT INTO `partida` (hcomienzo,hfinal) VALUES ("2025-09-20 11:30:00","2025-09-20 11:40:00");
INSERT INTO `partida` (hcomienzo,hfinal) VALUES ("2025-09-16 09:30:00","2025-09-16 09:40:00");
INSERT INTO `partida` (hcomienzo,hfinal) VALUES ("2025-09-15 10:30:00","2025-09-15 10:40:00");

-- Participante
INSERT INTO `participante` (apodo,idPartida,puntos,ganador) VALUES ("cjx",1,32,1);
INSERT INTO `participante` (apodo,idPartida,puntos,ganador) VALUES ("linus",1,30,0);
INSERT INTO `participante` (apodo,idPartida,puntos,ganador) VALUES ("python",1,30,0);
INSERT INTO `participante` (apodo,idPartida,puntos,ganador) VALUES ("tux",1,29,0);

-- Recinto
INSERT INTO `recinto` (nombre,descripcion,limiteFigura) VALUES ("equivalencia","Figuras del mismo color",6);
INSERT INTO `recinto` (nombre,descripcion,limiteFigura) VALUES ("soledad","Solo una figura",1);
INSERT INTO `recinto` (nombre,descripcion,limiteFigura) VALUES ("diferencia","Figuras de diferente color",6);
INSERT INTO `recinto` (nombre,descripcion,limiteFigura) VALUES ("rey","Apuesta por una figura",1);
INSERT INTO `recinto` (nombre,descripcion,limiteFigura) VALUES ("rio","Las figuras que quieras descartar, es aquí!",12);
INSERT INTO `recinto` (nombre,descripcion,limiteFigura) VALUES ("amor","Parejas de figuras con el mismo color",6);
INSERT INTO `recinto` (nombre,descripcion,limiteFigura) VALUES ("triada","Solo 3 figuras",3);

-- Tablero
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("cjx",1,1);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("cjx",1,2);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("cjx",1,3);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("cjx",1,4);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("cjx",1,5);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("cjx",1,6);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("cjx",1,7);

INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("linus",1,1);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("linus",1,2);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("linus",1,3);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("linus",1,4);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("linus",1,5);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("linus",1,6);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("linus",1,7);

INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("python",1,1);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("python",1,2);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("python",1,3);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("python",1,4);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("python",1,5);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("python",1,6);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("python",1,7);

INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("tux",1,1);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("tux",1,2);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("tux",1,3);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("tux",1,4);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("tux",1,5);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("tux",1,6);
INSERT INTO `tablero` (apodo,idPartida,idRecinto) VALUES ("tux",1,7);

-- Figura
INSERT INTO `figura` (nombre,color) VALUES ("piglin","amarillo");
INSERT INTO `figura` (nombre,color) VALUES ("enderman","negro");
INSERT INTO `figura` (nombre,color) VALUES ("magma","rojo");
INSERT INTO `figura` (nombre,color) VALUES ("creeper","verde");
INSERT INTO `figura` (nombre,color) VALUES ("bruja","morado");
INSERT INTO `figura` (nombre,color) VALUES ("zombie","azul");

-- Colocación
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("cjx",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("cjx",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("cjx",1,2,2);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("cjx",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("cjx",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("cjx",1,3,5);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("cjx",1,3,4);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("cjx",1,3,3);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("cjx",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("cjx",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("cjx",1,4,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("cjx",1,3,2);

INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("linus",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("linus",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("linus",1,2,2);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("linus",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("linus",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("linus",1,3,5);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("linus",1,3,4);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("linus",1,3,3);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("linus",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("linus",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("linus",1,4,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("linus",1,3,2);

INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("python",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("python",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("python",1,2,2);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("python",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("python",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("python",1,3,5);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("python",1,3,4);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("python",1,3,3);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("python",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("python",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("python",1,4,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("python",1,3,2);

INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("tux",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("tux",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("tux",1,2,2);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("tux",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("tux",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("tux",1,3,5);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("tux",1,3,4);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("tux",1,3,3);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("tux",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("tux",1,1,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("tux",1,4,1);
INSERT INTO `colocacion` (apodo,idPartida,idRecinto,idFigura) VALUES ("tux",1,3,2);
