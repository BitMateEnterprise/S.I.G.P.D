<?php
class ValidarEntradas{
  public function validarLogin(string $apodo,string $clave): ?string {    
    if (!preg_match('/^[a-zA-Z0-9]+$/', $apodo)) {
        return 'El nombre de usuario solo puede contener letras y números.';
    }
    
    if (strlen($apodo) < 3) {
        return 'El nombre de usuario debe tener al menos 3 caracteres.';
    }
    
    if (strlen($apodo) > 30) {
        return 'El nombre de usuario no puede exceder 30 caracteres.';
    }

    // Validar largo de contraseña
    if (strlen($clave) < 4) {
        return 'La contraseña debe tener al menos 4 caracteres.';
    }
    
    if (strlen($clave) > 30) {
        return 'La contraseña es demasiado larga.';
    }

    return null; // Todo válido
  }

  private function validarEmail(string $email): ?string {
    $email = trim($email);
    if ($email === '') {
         return 'El email es obligatorio.';
    }
        
    if (strlen($email) > 55) {
        return 'El email es demasiado largo.';
    }
        
    // Validación básica con filter_var
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return 'El formato del email no es válido.';
    }
        
    // Validación adicional de formato
    if (!preg_match('/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/', $email)) {
        return 'El email contiene caracteres no permitidos.';
    }
    return null;
  }   

  public function validarRegistro(string $apodo,string $clave, string $email): ?string{
    $error = $this->validarLogin($apodo,$clave);
    if($error !== null){
      return $error;
    }
    
    return $this->validarEmail($email);
  }
}