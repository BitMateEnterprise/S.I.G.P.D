<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Registro - Draftosaurus</title>
  <link rel="icon" type="image/png" href="assets/Imagenes/Logo.png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body{
      background-image: url("assets/Imagenes/fondoRegistro.png");
      background-repeat: no-repeat;
      background-size: cover;
      background-attachment: fixed;    
    }
  </style>
</head>
<body class="d-flex justify-content-center align-items-center vh-100" style="background-color: #fff9c4;">

  <div class="bg-light p-4 rounded shadow w-100" style="max-width: 360px;">
    <h2 class="text-center mb-4">Registro de Usuario</h2>
    
    <!-- Formulario -->
    <form action="index.php?ruta=registro" method="post" id="enviarDatos">
    <p id='mensaje' class=text-center style=color:red>
    <?php
      if(isset($mensaje)){
        echo htmlspecialchars($mensaje);
      }
    ?>
    </p><br>
  
      <div class="mb-3">
        <label for="nombre" class="form-label">Correo Electrónico</label>
        <input type="email" class="form-control" id="email" name="email" required>
        <div id="errorEmail" class="text-danger mt-1" style="display:none;">
         El formato del correo electrónico no es válido.
        </div>
      </div>
      <div class="mb-3">
        <label for="usuario" class="form-label">Nombre de usuario</label>
        <input type="text" class="form-control" id="usuario" name="apodo" required> 
      </div>
      <div class="mb-3">
        <label for="clave" class="form-label">Contraseña</label>
        <input type="password" class="form-control" id="clave" name="clave" required>
      </div>
      <button type="submit" class="btn btn-success w-100">Registrarse</button>
    </form>
  </div>

  <div id="modalExito" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 9999; justify-content: center; align-items: center;">
  <div style="text-align: center;">
     <p style="color: white; font-size: 20px; margin-top: 20px;">Registro exitoso</p>
    <script src="https://unpkg.com/@lottiefiles/dotlottie-wc@0.8.1/dist/dotlottie-wc.js" type="module"></script>
    <dotlottie-wc 
      id="animacionExito"
      src="https://lottie.host/36773353-bd72-425e-87a7-53ed02fd584e/u2KNKX0hfU.lottie" 
      style="width: 300px; height: 300px;" 
      autoplay>
    </dotlottie-wc>  
  </div>
  </div>

<script src="js/validarLogin.js"></script>
<script src="js/validarMail.js"></script>
<script>
<?php if($registroExitoso === true): ?>
  const modal = document.getElementById('modalExito');
  modal.style.display = 'flex';
    
  // Redireccionar después de 3 segundos
  setTimeout(function() {
    window.location.href = 'index.php?ruta=login';
  }, 3000);
<?php endif; ?>
</script>

</body>
</html>
