<?php
class FinPartida{
  public function limpiarSesion(){
    if(isset($_SESSION["resultados"]) || isset($_SESSION["idPartida"])){
      unset($_SESSION["jugadores"]);
      unset($_SESSION["resultados"]);
      unset($_SESSION["idPartida"]);
      echo "<script>localStorage.clear()
      window.location.href='index.php?ruta=perfil'</script>";
      exit();
    }
  }
}