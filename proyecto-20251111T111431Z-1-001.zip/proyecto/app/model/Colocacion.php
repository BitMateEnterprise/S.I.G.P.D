<?php

class Colocacion { 
  private string $apodo;
  private int $idFigura;
  private int $idRecinto;
  private int $idPartida;
 
  public function __construct(string $apodo, int $idFigura, int $idRecinto, int $idPartida) {
    $this->apodo = $apodo;
    $this->idFigura = $idFigura;
    $this->idRecinto = $idRecinto;
    $this->idPartida = $idPartida;
  }

  public function getApodo(): string {
      return $this->apodo;
  }

  public function getIdFigura(): int {
      return $this->idFigura;
  }

  public function getIdRecinto(): int {
      return $this->idRecinto;
  }

  public function getIdPartida(): int {
      return $this->idPartida;
  }
}    