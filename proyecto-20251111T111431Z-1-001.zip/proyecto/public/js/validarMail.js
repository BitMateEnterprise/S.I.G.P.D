const emailInput = document.getElementById("email");
const errorEmail = document.getElementById("errorEmail");

// Expresión regular. El ^ dentro de los corchetes niega lo esa parte de la regex. Entonces se evalúa que no haya @ o cualquier espaciado.
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

emailInput.addEventListener("input", () => {
  const correo = emailInput.value.trim();

  if (correo === "" || emailRegex.test(correo)) {
    errorEmail.style.display = "none";
    emailInput.classList.remove("is-invalid");
  } else {
    errorEmail.style.display = "block";
    emailInput.classList.add("is-invalid");
  }
});