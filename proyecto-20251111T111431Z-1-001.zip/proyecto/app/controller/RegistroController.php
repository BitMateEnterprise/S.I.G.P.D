<?php
class RegistroController{
  public function registro(){
    if($_SERVER["REQUEST_METHOD"] === "POST"){
      $apodo = trim($_POST["apodo"]) ?? "";
      $clave = trim($_POST["clave"]) ?? ""; 
      $email = trim($_POST["email"]) ?? "";;
      require_once 'ValidarEntradas.php'; 
      $mensaje = (new ValidarEntradas())->validarRegistro($apodo,$clave,$email);

      if($mensaje === null){
        require_once __DIR__ . '/../model/UsuarioDAO.php';
        require_once __DIR__ . '/../model/Usuario.php';
        $usuarioDAO = new UsuarioDAO();

        if($usuarioDAO->consultarUsuario($apodo) !== ""){
          $mensaje = "Este usuario ya existe. Ingrese otro nombre";
        }else{
          $usuario = new Usuario($apodo,$clave,$email);
          $usuarioDAO->crearUsuario($usuario);
          $registroExitoso = true;
        }        
      } 
    }
    require_once __DIR__ . '/../view/registro.php';
  }
}
?>