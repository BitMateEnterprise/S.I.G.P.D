<?php

class Jugador{
  private string $apodo;
  private int $idPartida;
  private int $puntos;
  private bool $ganador;

  public function __construct(string $apodo,int $idPartida,int $puntos=0, bool $ganador=false){
    $this->apodo = $apodo;
    $this->idPartida = $idPartida;
    $this->$puntos = $puntos;
    $this->$ganador =  $ganador;
  }

  public function agregar(){
    
  }

  public function ganador(){

  }

  public function getApodo(): string {
    return $this->apodo;
  }

  public function getIdPartida(): int {
    return $this->idPartida;
  }

  public function getPuntos(): int {
    return $this->puntos;
  }

  public function getGanador(): bool {
    return $this->ganador;
  }
}