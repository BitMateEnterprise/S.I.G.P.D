<?php

require_once __DIR__ . '/../model/RecintoDAO.php';
require_once __DIR__ . '/../model/FiguraDAO.php';
require_once __DIR__ . '/../model/ColocacionDAO.php';
require_once __DIR__ . '/../model/JugadorDAO.php';
require_once __DIR__ . '/../model/PartidaDAO.php';
require_once __DIR__ . '/../model/Colocacion.php';

class PuntosController{

	private array $recintos;
	private array $figuras;

	public function __construct(){
		$this->recintos = (new RecintoDAO)->getRecinto();
		$this->figuras = (new FiguraDAO)->getFigura();
	}

  private function calcularPuntos(array $tablero): int{
		$puntos = 0;

		$equivalencia = [0,2,4,8,12,18,24];
		$puntos+=$equivalencia[count($tablero["equivalencia"])];
					
		$diferencia = [0,1,3,6,10,15,21];
		$puntos+=$diferencia[count($tablero["diferencia"])];
			

		if(count($tablero["triada"]) === 3) $puntos+=7;

		$puntos+=count($tablero["rio"]);

		if(!empty($tablero["soledad"])){
			$puntos+=$this->validarSoledad($tablero) ? 7 : 0;
		}

		if(!empty($tablero["amor"])){
			$repetidas = array_count_values($tablero["amor"]);
			foreach($repetidas as $cantidad){
				$puntos+= floor($cantidad / 2) * 5;
			}
		}
		return $puntos;
	}

  private function validarSoledad(array $tablero): bool{
		$figuraSoledad = $tablero["soledad"][0];
		foreach($tablero as $recinto => $figurasColocadas){			
			if(in_array($figuraSoledad,$figurasColocadas) && $recinto !== "soledad") return false;
		}
		return true;
	}

  private function puntosCreeper(array $tablero): int{
		$creeper = 0;
		foreach($tablero as $recinto){
			if(in_array("creeper",$recinto)) $creeper++;
		}
		return $creeper;
	}

  private function contarRey(array $tablero, string $figuraRey): int{
		$cantidad = 0;
		foreach($tablero as $recinto){
			$aux = array_count_values($recinto);
			$cantidad+=$aux[$figuraRey] ?? 0; 
		}
		return $cantidad;
	}

  private function puntosRey(array $tableros, string $figuraRey, string $nombreJugador): int{
		$jugadoresRey = [];
		foreach($tableros as $jugador => $tablero){
			$cantRey = $this->contarRey($tablero,$figuraRey);
			$jugadoresRey[$jugador] = $cantRey;
		}
		arsort($jugadoresRey);
		$cantJugador = $jugadoresRey[$nombreJugador];
		return $cantJugador === array_shift($jugadoresRey) ? 7 : 0;
	}

  public function puntos(){
    header("Content-Type: application/json");
		$tableros = json_decode($_POST["tableros"],true);
		$puntaje = [];

		foreach($tableros as $nombreJugador => $tablero){
			$puntosJug = 0;
			if(!empty($tablero["rey"])){
				$figuraRey = $tablero["rey"][0];
				$puntosRey = $this->puntosRey($tableros,$figuraRey,$nombreJugador);
				$puntosJug+=$puntosRey;				
			}						
			$puntosJug+=$this->puntosCreeper($tablero);
			$puntosJug+=$this->calcularPuntos($tablero);
			$puntaje[$nombreJugador] = $puntosJug;

			(new JugadorDAO())->puntos($nombreJugador,$puntosJug,$_SESSION["idPartida"]);

			$this->colocacion($tablero,$nombreJugador);
		}
		arsort($puntaje);
		$this->JugGanador($puntaje,$tableros);
		$this->finPartida();

		$_SESSION["resultados"] = $puntaje;

		echo json_encode(['exito' => true]); 
  }

	private function JugGanador(array &$puntaje,array $tableros){
		$jugadores = array_keys($puntaje,max($puntaje));
		if(count($jugadores) === 1){
			(new JugadorDAO())->ganador($jugadores[0],$_SESSION["idPartida"]);
			return;	
		}

		$ganadores = $this->ganadorCreeper($tableros,$jugadores);
		$ganadoresConPuntos = [];
    foreach($ganadores as $ganador){
        $ganadoresConPuntos[$ganador] = $puntaje[$ganador];
        unset($puntaje[$ganador]);
    }
    
    $puntaje = $ganadoresConPuntos + $puntaje;

		$jugadorDAO = new JugadorDAO();
		foreach($ganadores as $ganador){
			$jugadorDAO->ganador($ganador,$_SESSION["idPartida"]);
		}
	}

	private function ganadorCreeper(array $figuras,array $ganadores){
  $creeperJug = []; 
  
  foreach($ganadores as $jugador){
    $creepers = 0;
    foreach($figuras[$jugador] as $mobs){     
      $fichas = array_count_values($mobs);
      $creepers+=$fichas["creeper"] ?? 0;      
    }    
    $creeperJug[$jugador] = $creepers;
  }
  return array_keys($creeperJug,max($creeperJug));
	}

	private function colocacion(array $tablero, string $jugador){
		$idPartida = $_SESSION["idPartida"];
		$colocacionDAO = new ColocacionDAO();

		foreach($tablero as $recinto => $figuras){
			if(!empty($figuras)){
				foreach($figuras as $figura){
					$colocacion = new Colocacion($jugador,$this->figuras[$figura],$this->recintos[$recinto],$idPartida);
					$colocacionDAO->insertar($colocacion);
				}
			}
		}
	}

	private function finPartida(){
		$horaFinal = date('Y-m-d H:i:s');
		(new PartidaDAO())->fin($horaFinal,$_SESSION["idPartida"]);
	}

}