<?php
require_once __DIR__.'/../model/JugadorDAO.php';
$datosJugador = new JugadorDAO();
$estadisticas = $datosJugador->getEstadisticas($_SESSION["usuario"]);
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Perfil - Drafto Craft</title>
  <link rel="icon" type="image/png" href="assets/Imagenes/Logo.png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="../public/css/perfil.css">

</head>
<body class="align-items-center vh-100">

<header>
  <div class="container-fluid p-0">
    <nav class="navbar navbar-light justify-content-between p-2 " style="background-color: #003A70;">
      <div>
        <img src="assets/Imagenes/logo_bitmate.png" class="logo">
        <span class="logo-text">BitMate</span>
      </div>     
      <div class="form-inline">
        <a href="index.php?ruta=logout" class="btn btn-outline-light my-2 my-sm-0">Salir</a>
        <form method="POST" action="index.php?ruta=eliminarCuenta" id="eliminarUsuario" style="display:inline;">
          <input type="hidden" name="apodo" value="<?php echo htmlspecialchars($_SESSION["usuario"]); ?>">
          <button type="button" id="eliminarCuenta" class="btn btn-outline-danger my-2 my-sm-0">Eliminar Cuenta</button>
        </form>
      </div>
    </nav>
  </div>
</header>

  <div class="container text-center border rounded p-4 shadow justify-content-center " style="width: 90%; max-width: 400px; background-color: rgba(200, 200, 200, 0.6); backdrop-filter: blur(6px); margin-top: 250px">
    <!-- Nombre -->
    <h2 class="mb-4"><?=$_SESSION["usuario"]?></h2>

    <!-- Estadísticas -->
    <div class="mb-4">
      <h5 class="mb-2">Estadísticas</h5>
      <ul class="list-group">
        <li class="list-group-item d-flex justify-content-between">
          <span>Partidas Jugadas</span>
          <span><?=$estadisticas->getPartidasJugadas()?></span>
        </li>
        <li class="list-group-item d-flex justify-content-between">
          <span>Partidas Ganadas</span>
          <span><?=$estadisticas->getPartidasGanadas()?></span>
        </li>
        <li class="list-group-item d-flex justify-content-between">
          <span>Puntaje Total</span>
          <span><?=$estadisticas->getTotalPuntos()?></span>
        </li>
      </ul>
    </div>

    <!-- Botones -->
    <div class="d-flex flex-column gap-2">
      <button id="update-user-button" class="btn btn-primary" data-apodo="<?php echo htmlspecialchars($_SESSION['usuario']); ?>">Editar Perfil</button>
      <a href="index.php?ruta=salaEspera" class="btn btn-success">Comenzar Partida de Seguimiento</a>
      <button id="rankingGlobal" class="btn btn-warning">Mostrar Ranking Global</button>
    </div>
  </div>  

 <!-- Modal Ranking Global -->
<div class="modal fade" id="modalRanking" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content shadow-lg border-0 rounded-4 overflow-hidden">

      <!-- Encabezado -->
      <div class="modal-header bg-success text-white justify-content-center">
        <h5 class="modal-title m-0" id="modalRankingLabel">🏆 Ranking de Jugadores</h5>
      </div>

      <!-- Cuerpo -->
      <div class="modal-body p-0">
        <table class="table table-striped text-center mb-0 align-middle">
          <thead class="table-success">
            <tr>
              <th>#</th>
              <th>Jugador</th>
              <th>Puntos</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($estadisticas->getRanking() as $i => $j): ?>
              <tr>
                <td><?= $i + 1 ?></td>
                <td><?= htmlspecialchars($j['apodo']) ?></td>
                <td><?= htmlspecialchars($j['puntos']) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <div class="modal-footer justify-content-center bg-light border-0">
        <small class="text-muted">✨ Fin del Ranking ✨</small>
      </div>

    </div>
  </div>
</div>

<!-- Modal Modificar -->
  <div class="modal fade" id="editarUsuario" tabindex="-1" aria-labelledby="editarUsuarioLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content p-4 rounded-3">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <h2 id="editarUsuarioLabel" class="h5 m-0">Modificar Datos</h2>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
        </div>
      
        <form action="index.php?ruta=actualizarDatos" method="post">
          <input type="text" id="apodo" name="apodo" placeholder="Apodo" class="form-control mb-2" readonly>
          <input type="email" id="email" name="email" placeholder="Email" class="form-control mb-2" required>
          <!-- <input type="password" id="contra" name="clave" placeholder="Contraseña" class="form-control mb-3" required> -->
          <button type="submit" class="btn btn-outline-primary w-100">Modificar</button>
        </form>
      </div>
    </div>
  </div>

<!-- Modal Eliminar-->

<div class="modal fade" id="modalEliminarCuenta" tabindex="-1" aria-labelledby="modalEliminarCuentaLabel" aria-hidden="true" >
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-danger text-white">
        <h5 class="modal-title" id="modalEliminarCuentaLabel">Confirmar eliminación</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body">
        <p>¿Desea eliminar su cuenta? Esta acción desactivará su perfil y no podrá acceder nuevamente.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
        <button type="button" class="btn btn-danger" id="btnEliminarSi">Sí</button>
      </div>
    </div>
  </div>
</div>

  
  <script>
    // Iniciar clase Modal de Bootstrap para usar su clase .show()
    const editarUsuario = new bootstrap.Modal("#editarUsuario");
    const botonModificar = document.getElementById("update-user-button");

    // Al hacer click en el boton con id update-user-button, abre el modal
    botonModificar.addEventListener("click", e => {
      e.preventDefault();
      const apodo = botonModificar.getAttribute("data-apodo");
      fetch(`index.php?ruta=obtener&apodo=${apodo}`)
        .then(res => res.json())
        .then(data => {
          document.getElementById('apodo').value = apodo;
          document.getElementById('email').value = data;
        })
        .catch(err => console.error(err));      
      editarUsuario.show();
    });
  </script>

  <script> 
    const modalRanking = new bootstrap.Modal('#modalRanking');
    document.getElementById('rankingGlobal').addEventListener('click', () => modalRanking.show());
  </script>

  
  <script src="js/eliminarUsuario.js"></script>

</body>
</html>
