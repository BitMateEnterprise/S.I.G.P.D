<?php

class Conexion{
  private static ?Conexion $instancia = null;
  private PDO $conexion;

  private function __construct(){

    try{
      $this->conexion = new PDO("mysql:host=localhost;dbname=draftodb;charset=utf8mb4", "root", "");
    }catch(PDOException $e){
      echo "Una cagada la conexión ".$e->getMessage();
  }
}
  
  public static function getInstancia(): Conexion {
    if (self::$instancia === null) {
     self::$instancia = new Conexion(); // $this->instancia = new Conexion(); error
    }
    return self::$instancia;
  }

  public function getConexion(): PDO{
    return $this->conexion;
  }
}

?>